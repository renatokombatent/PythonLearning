'''Exercício Python 059: Crie um programa que leia dois valores e mostre um menu na tela:
[ 1 ] somar
[ 2 ] multiplicar
[ 3 ] maior
[ 4 ] novos números
[ 5 ] sair do programa
Seu programa deverá realizar a operação solicitada em cada caso.'''

escolha = ''
print('MINI CALCULADORA EM PYTHON')

while escolha != 0:

    n1 = int(input('Informe o 1º número: '))
    n2 = int(input('Informe o 2º número: '))

    print(
    ''' [1 - SOMAR]
    [2 - SUBTRAIR]
    [3 - MULTIPLICAR]
    [4 - DIVISÃO]
    [0 - SAIR DO PROGRAMA]''')

    escolha = int(input('Qual operação deseja fazer?: '))

    if escolha == 1:
        resp = n1 + n2
        print(f'A SOMA de {n1} + {n2} é igual a: {resp}.')
    elif escolha == 2:
        resp = n1 - n2
        print(f'A SUBTRAÇÃO de {n1} - {n2} é igual a: {resp}')
    elif escolha == 3:
        resp = n1 * n2
        print(f'A MULTIPLICAÇÃO de {n1} * {n2} é igual a {resp}.')
    elif escolha == 4:
        resp = n1 / n2
        print(f'A DIVISÃO de {n1} / {n2} é igual a {resp}.')
    elif escolha == 0:
        print('FIM DO PROGRAMA.')
        break
    else:
        print('Escolha inválida, tente novamente!')
print('OBRIGADO POR USAR A CALCULADORA PYTHON')