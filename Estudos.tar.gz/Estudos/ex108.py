'''Exercício Python 108: Adapte o código do desafio #107, criando uma função adicional chamada moeda() que consiga mostrar os números como um valor monetário formatado.'''


from uteis import moedas

num = int(input('Digite um número: '))
print(f'O dobro de {moedas.moeda(num)} é {moedas.moedas(num )}.')
print(f'A metade de {moedas.moeda(num)} é {moedas.metade(num)}.')
print(f'O aumento de {num} é {moedas.moeda(moedas.aumento(num, 10))}')
print(f'Diminuir {num} o fica {moedas.moeda(moedas.diminuir(num, 10))}.')