'''Exercício Python 056: Desenvolva um programa que leia o nome, idade e sexo de 4 pessoas. No final do programa, mostre: a média de idade do grupo, qual é o nome do
homem mais velho e quantas mulheres têm menos de 20 anos.'''

totIdade = 0
mediaIdade = 0
homemVelho = 0
nomeHomem = ''
quantMulheres = 0

for c in range(1, 5):
    nome = str(input(f'Informe o nome da {c}º pessoa: '))
    idade = int(input(f'Informe a idade da {c}º pessoa: '))
    sexo = str(input(f'Informe o sexo da {c}º pessoa: [M/F] ')).upper()
    '''Média de idade'''
    totIdade += idade
    mediaIdade = totIdade / 4
    '''Homem mais velho'''
    if sexo == 'M':
        if c == 1:
            homemVelho = idade
        else:
            if idade > homemVelho:
                homemVelho = idade
                nomeHomem = nome
    '''Mulheres menores de 20'''
    if sexo == 'F' and idade < 20:
        quantMulheres += 1
    print(f'O nome da {c}º pessoa é {nome}, o sexo é {sexo} e tem {idade} anos de idade.')


print(f'A média de idade do grupo é de {mediaIdade}.')
print(f'A idade do homem mais velho é {homemVelho} e seu nome é {nomeHomem}.')
print(f'Este grupo possui {quantMulheres} mulhere(s) com menos de 20 anos de idade.')