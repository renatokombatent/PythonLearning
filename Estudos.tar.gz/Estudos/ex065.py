'''Exercício Python 065: Crie um programa que leia vários números inteiros pelo teclado. No final da execução, mostre a média entre todos os valores e qual foi o maior e o
menor valores lidos. O programa deve perguntar ao usuário se ele quer ou não continuar a digitar valores.'''


cont = 0
soma = 0
maior = 0
menor = 0
media = 0
quant = 0

while cont != 'N':
    n = int(input('Digite um número: '))
    soma += n
    quant += 1
    if quant == 1:
        maior = menor = n
    else:
        if n > maior:
            maior = n
        elif n < menor:
            menor = n
    cont = str(input('Deseja continua? [S/N]: ')).upper().strip()
    if cont == 'N':
        break

media = soma / quant
print(f'A média dos valores digitados é: {media:.2f}')
print(f'O maior número digitado foi {maior}, e o menor foi {menor}.')
print('Fim do programa')