'''Exercício Python 054: Crie um programa que leia o ano de nascimento de sete pessoas. No final, mostre quantas pessoas ainda não atingiram a maioridade e quantas já são maiores.'''
import datetime

ano = datetime.date.today().year
maior = 0
menor = 0

for c in range(1, 8):
    nascimento = int(input(f'Informe o ano de nascimento da {c}º pessoa: '))
    idade = ano - nascimento
    if idade < 18:
        menor += 1
    else:
        maior += 1
    print(f'A {c}º pessoa tem {idade} anos de idade.')

print(f'No total, temos {maior} pessoas maiores de idade e {menor} pessoas menores de idade.')

