'''Exercício Python 094: Crie um programa que leia nome, sexo e idade de várias pessoas, guardando os dados de cada pessoa em um dicionário e todos os dicionários em uma lista.
No final, mostre:
A) Quantas pessoas foram cadastradas
B) A média de idade
C) Uma lista com as mulheres
D) Uma lista de pessoas com idade acima da média'''


lista = dict()
cadastro = list()
mulheres = list()
velhos = list()
pessoas = 0
media = 0
mediafinal = 0

while True:

    lista['nome'] = str(input('Qual o seu nome?: '))
    pessoas += 1
    lista['sexo'] = str(input('Informe seu sexo [M/F]: ')).upper()
    if lista['sexo'] == 'F':
        mulheres.append(lista['nome'])
    lista['idade'] = int(input('Qual é a sua idade? '))
    media += lista['idade']
    if lista['idade'] >= 50:
        velhos.append(lista['nome'])
    cadastro.append(lista.copy())

    cont = str(input('Deseja continuar?: ')).upper()
    if cont == 'N':
        break
mediafinal = (media * pessoas) / pessoas
mediagrupo = mediafinal / pessoas
if mediagrupo >= 50:
    velhos.append(mediagrupo)

print(cadastro)
print(mulheres)
print(pessoas)
print(velhos)
