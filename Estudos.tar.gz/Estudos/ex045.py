'''Exercício Python 045: Crie um programa que faça o computador jogar Jokenpô com você.'''


from random import randint
from time import sleep

chances = 3

while(True):

    print('Suas opções: \n'
          '[0] PEDRA\n'
          '[1] PAPEL\n'
          '[2] TESOURA')

    print(f'\033[31mVocê tem {chances} para jogar.\033[m')
    escolha = int(input('\033[34mQual é a sua escolha: \033[m'))
    comp = randint(0, 2)

    if escolha == 0 and comp == 0:
        sleep(0.5)
        print('\033[32mVocê escolheu PEDRA.\033[m')
        sleep(0.5)
        print('\033[36mO computador escolheu: PEDRA, empatou.\033[m.')
        sleep(0.5)
    elif escolha == 0 and comp == 1:
        sleep(0.5)
        print('\033[32mVocê escolheu PEDRA\033[m.')
        sleep(0.5)
        print('\033[36mO computador escolheu PAPEL, você perdeu...\033[m')
        chances -= 1
        sleep(0.5)
    elif escolha == 0 and comp == 2:
        sleep(0.5)
        print('\033[32mVocê escolheu PEDRA\033[m.')
        sleep(0.5)
        print('\033[36mO computador escolheu TESOURA, você ganhou!\033[m')
        sleep(0.5)
    elif escolha == 1 and comp == 0:
        sleep(0.5)
        print('\033[37mVocê escolheu PAPEL.\033[m')
        sleep(0.5)
        print('\033[33mO computador escolheu PEDRA, você ganhou!\033[m')
        sleep(0.5)
    elif escolha == 1 and comp == 1:
        sleep(0.5)
        print('\033[37mVocê escolheu PAPEL.\033[m')
        sleep(0.5)
        print('\033[33mO computador escolheu PAPEL, empatou.\033[m')
        sleep(0.5)
    elif escolha == 1 and comp == 2:
        sleep(0.5)
        print('\033[37mVocê escolheu PAPEL.\033[m')
        sleep(0.5)
        print('\033[33mO computador escolheu TESOURA, você perdeu...\033[m')
        chances -= 1
        sleep(0.5)
    elif escolha == 2 and comp == 0:
        sleep(0.5)
        print('\033[35mVocê escolheu TESOURA.\033[m')
        sleep(0.5)
        print('\033[34mO computador escolheu PEDRA, você perdeu...\033[m')
        chances -= 1
        sleep(0.5)
    elif escolha == 2 and comp == 1:
        sleep(0.5)
        print('\033[35mVocê escolheu TESOURA.\033[m')
        sleep(0.5)
        print('\033[34mO computador escolheu PAPEL, você ganhou!\033[m')
        sleep(0.5)
    elif escolha == 2 and comp == 2:
        sleep(0.5)
        print('\033[35mVocê escolheu TESOURA.\033[m')
        sleep(0.5)
        print('\033[34mO computador escolheu TESOURA, empatou.\033[m')
        sleep(0.5)
    else:
        sleep(0.5)
        print('Escolha inválida, tente novamente!')
        sleep(0.5)

    if chances <= 0:
        print('Suas chances acabaram, GAME OVER.')
        break

    cont = str(input('Quer jogar outra partida?: [S/N] ')).upper()
    sleep(0.5)
    while (True):
        if cont == 'N':
            sleep(0.5)
            print('FIM DE JOGO!')
            sleep(0.5)
        break
