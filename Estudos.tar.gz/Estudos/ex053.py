'''Exercício Python 053: Crie um programa que leia uma frase qualquer e diga se ela é um palíndromo, desconsiderando os espaços.

Exemplos de palíndromos: APOS A SOPA, A SACADA DA CASA, A TORRE DA DERROTA, O LOBO AMA O BOLO, ANOTARAM A DATA DA MARATONA.'''

p1 = str(input('Digite uma frase: ')).strip().upper()
palavras = p1.split()
junto = ''.join(palavras)
inverso = ''

for letra in range(len(junto) -1, - 1, -1):
    inverso += junto[letra]
if inverso == junto:
    print(f'O inverso de {junto} é {inverso}.')
    print('Essa frase é um palindromo.')
else:
    print('A frase digita não é um palindromo.')




