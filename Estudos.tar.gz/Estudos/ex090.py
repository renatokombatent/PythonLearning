'''Exercício Python 090: Faça um programa que leia nome e média de um aluno, guardando também a situação em um dicionário. No final, mostre o conteúdo da estrutura na tela.'''

situacao = dict()
situacao['situação'] = 0

situacao['nome'] = str(input('Informe o seu nome: '))
situacao['nota'] = float(input('Informe sua primeira nota: '))
situacao['nota2'] = float(input('Informe sua segunda nota: '))
situacao['media'] = (situacao['nota'] + situacao['nota2']) / 2
if situacao['media'] <= 6:
    situacao['situação'] = str('Reprovado')
elif situacao['media'] >= 7:
    situacao['situação'] = str('Aprovado')

print('Seu nome e média final sâo: ')
print(situacao['nome'], situacao['media'])
print('Sua situação completa é:')
print(situacao)