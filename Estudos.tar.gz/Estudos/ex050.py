'''Exercício Python 050: Desenvolva um programa que leia seis números inteiros e mostre a soma apenas daqueles que forem pares. Se o valor digitado for ímpar, desconsidere-o.'''


somaTotal = 0
pares = []
impares = []

for c in range(1,7):
    c = int(input(f'Informe o {c}º número: '))
    if c % 2 == 0:
        somaTotal += c
        pares.append(c)
    else:
        impares.append(c)

print(f'Os números pares somados foram: {pares}.')
print(f'A soma de todos os números pares é: {somaTotal}.')
print(f'Os números descartados foram: {impares}.')