'''Exercício Python 093: Crie um programa que gerencie o aproveitamento de um jogador de futebol. O programa vai ler o nome do jogador e quantas partidas ele jogou.
Depois vai ler a quantidade de gols feitos em cada partida. No final, tudo isso será guardado em um dicionário, incluindo o total de gols feitos durante o campeonato.'''


aprov = dict()
gpartida = 0
aprov['jogador'] = str(input('Informe o nome do jogador: '))
aprov['partidas'] = int(input(f'Quantas partidas o jogador {aprov["jogador"]} jogou?: '))
for c in range(aprov['partidas']):
    gols = int(input(f'Quantos gols o jogador fez na {c + 1}º partida?: '))
    gpartida += gols
    aprov['totGols'] = gpartida
print(aprov)


