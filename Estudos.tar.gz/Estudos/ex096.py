
def area(l, c):
    a = l * c
    print(f'Com largura de {l} e comprimento de {c}, seu terreno tem a área de {a}m².')


l = float(input('Informe a largura do seu terreno: '))
c = float(input('Informe o comprimento do seu terreno: '))
area(l, c)