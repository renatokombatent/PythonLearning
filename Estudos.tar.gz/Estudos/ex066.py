'''Exercício Python 066: Crie um programa que leia números inteiros pelo teclado. O programa só vai parar quando o usuário digitar o valor 999, que é a condição de parada.
No final, mostre quantos números foram digitados e qual foi a soma entre elas (desconsiderando o flag).'''

n = 0
totNum = 0
somaNum = 0
while n != 999:
    n = int(input('Digite um número: [999 para terminar] '))
    totNum += 1
    somaNum += n
print('FIM DA DIGITAÇÃO PELO USUÁRIO!')
print(f'O total de número digitados foi {totNum - 1}.')
print(f'A soma de todos os números digitados é {somaNum - 999}.')
