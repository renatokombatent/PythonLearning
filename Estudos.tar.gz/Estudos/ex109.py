'''Exercício Python 109: Modifique as funções que form criadas no desafio 107 para que elas aceitem um parâmetro a mais, informando se o valor retornado por elas vai ser ou não
formatado pela função moeda(), desenvolvida no desafio 108.'''


from uteis import moedas

num = int(input('Digite um número: '))
print(f'O dobro de {moedas.moeda(num)} é {moedas.moedas(num, True )}.')
print(f'A metade de {moedas.moeda(num)} é {moedas.metade(num, True)}.')
print(f'O aumento de {num} é {moedas.moeda(moedas.aumento(num, 10, True))}')
print(f'Diminuir {num} o fica {moedas.moeda(moedas.diminuir(num, 10, True))}.')