'''Exercício Python 091: Crie um programa onde 4 jogadores joguem um dado e tenham resultados aleatórios. Guarde esses resultados em um dicionário em Python. No final, coloque
esse dicionário em ordem, sabendo que o vencedor tirou o maior número no dado.'''
import random
from operator import itemgetter
import ramdom

resltados = dict()
valores = list()
ranking = dict()

j1 = int(input('Precione a tecla zero para jogar um dado: '))
j1 = random.randint(1,6)
resltados['Jogador1'] = j1
valores.append(resltados['Jogador1'])
print(f'Você tirou {j1} no seu dado.')
print('=-' * 30)
j2 = int(input('Precione a tecla zero para jogar o segundo dado: '))
j2 = random.randint(1, 6)
resltados['Jogador2'] = j2
valores.append(resltados['Jogador2'])
print(f'Você tirou {j2} no seu dado.')
print('-=' * 30)
j3 = int(input('Precione a tecla zero para jogar o terceiro dado: '))
j3 = random.randint(1, 6)
resltados['Jogador3'] = j3
valores.append(resltados['Jogador3'])
print(f'Você tirou {j3} no seu dado.')
print('-=' * 30)
j4 = int(input('Precione a tecla zero para jogar o quarto dado: '))
j4 = random.randint(1, 6)
resltados['Jogador4'] = j4
valores.append(resltados['Jogador4'])
print(f'Você tirou {j4} no seu dado.')
print('-=' * 30)
ranking = sorted(resltados.items(), key= itemgetter(1), reverse=True)
print(ranking)