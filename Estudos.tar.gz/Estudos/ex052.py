'''Exercício Python 052: Faça um programa que leia um número inteiro e diga se ele é ou não um número primo.'''


tot = 0

n = int(input('Digite um número para saber se ele é primo: '))

for c in range(1, n + 1):
    if n % c == 0:
        print('\033[33m', end=' ')
        tot += 1
    else:
        print('\033[31m', end=' ')
        print(f'{c}', end=' ')
print(f'\nO número {n} foi divisível {tot} vezes.')
if tot == 2:
    print('Por isso ese é primo.')
else:
    print('Por isso ele não é primo.')