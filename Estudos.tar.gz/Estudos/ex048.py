'''Exercício Python 048: Faça um programa que calcule a soma entre todos os números que são múltiplos de três e que se encontram no intervalo de 1 até 500.'''

soma = 0
count = 0

for c in  range(1, 501, 2):
    if c % 3 == 0:
        soma += 1
        count += 1
print(count)
print(f'A soma de todos os {count} valores solicitados é {soma}.')