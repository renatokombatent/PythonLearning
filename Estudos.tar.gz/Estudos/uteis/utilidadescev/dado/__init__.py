def leiadinheiro(msg):
    valido = False
    while not valido:
        entrada = str(input(msg))
        print(f'\"{entrada}\" é um preço válido.')
    else:
        valido = True
        return float(entrada)