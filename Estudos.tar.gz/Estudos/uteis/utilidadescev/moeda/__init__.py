def moedas(preco=0, formato=False):
    res = preco*preco
    return res if formato is False else moedas(res)



def metade(preco, formato = False):
    res = preco/2
    return res if formato is False else moedas(res)


def aumento(preco, taxa, formato=False):
    res = preco + (preco * taxa/100)
    return res if formato is False else moedas(res)


def diminuir(preco, taxa, formato=False):
    res = preco - (preco + taxa/100)
    return res if formato is False else moedas(res)


def moeda(preco = 0, moeda = 'R$'):
    return f'{moeda}{preco:.2f}'.replace('.', ',')



def resumo(preco=0, taxaa=10, taxar=5):
    print('-' * 30)
    print('Resumo do valor'.center(30))
    print('-' * 30)
    print(f'Preço analisado: {moeda(preco)}')
    print(f'Dobro do preço: {moedas(preco, True)}')
    print(f'Metade do preço: {metade(preco, True)}')
    print(f'Com {taxaa}% de aumento: {aumento(preco, taxaa, True)}')
    print(f'{taxar}% de redução {diminuir(preco, taxar, True)}')
    print('-' * 30)