'''Exercício Python 101: Crie um programa que tenha uma função chamada voto() que vai receber como parâmetro o ano de nascimento de uma pessoa,
retornando um valor literal indicando se uma pessoa tem voto NEGADO, OPCIONAL e OBRIGATÓRIO nas eleições.'''
import datetime
'''from datetime import date
def voto(idade):
   if data - ano >= 18:
      print('-' * 30)
      print(idade)
      print('-' * 30)


data = date.today().year
ano = int(input('Qual o ano do seu nascimento?: '))
sit = data - ano

if sit >= 18 and sit <= 64:
   voto('Seu voto é obrigatório.')

elif sit >= 65:
   voto('Seu voto é opcional.')

elif sit >= 15 and sit <= 17:
   voto(print('Seu voto é opcional.'))

elif sit <= 14:
   voto(print('Você não vota ainda.'))

print(sit)'''

def voto(ano):
   from datetime import date
   atual = date.today().year
   idade = atual - ano
   if idade < 16:
      return f'Com {idade} anos, você não vota..'
   elif 16 <= idade < 18 or idade > 65:
      return (f'Com {idade} seu voto é opcional.')
   else:
      return f'Com {idade} seu voto é obrigatório.'

nasc = int(input('Informe o ano de seu nascimento: '))
print(voto(nasc))
