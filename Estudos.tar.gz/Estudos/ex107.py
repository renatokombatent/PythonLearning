'''Exercício Python 107: Crie um módulo chamado moeda.py que tenha as funções incorporadas aumentar(), diminuir(), dobro() e metade(). Faça também um programa que
importe esse módulo e use algumas dessas funções.'''

from uteis import moedas

num = int(input('Digite um número: '))
print(f'O dobro de {moedas.moeda(num)} é {moedas.moedas(num )}.')
print(f'A metade de {moedas.moeda(num)} é {moedas.metade(num)}.')
print(f'O aumento de {num} é {moedas.moeda(moedas.aumento(num, 10))}')
print(f'Diminuir {num} o fica {moedas.moeda(moedas.diminuir(num, 10))}.')