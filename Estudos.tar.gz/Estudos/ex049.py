'''Exercício Python 049: Refaça o DESAFIO 009, mostrando a tabuada de um número que o usuário escolher, só que agora utilizando um laço for.'''


from time import sleep

n = int(input('Digite um número para ver sua tabuada: '))
for c in range(1, 11):
    sleep(0.2)
    print(f'{c} x {n} = {c*n}')