


letras = ('J', 'X', 'M', 'O', 'A', 'K')
print(letras.index('A'))