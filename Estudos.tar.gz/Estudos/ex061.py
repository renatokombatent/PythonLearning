'''Exercício Python 061: Refaça o DESAFIO 051, lendo o primeiro termo e a razão de uma PA, mostrando os 10 primeiros termos da progressão usando a estrutura while.'''

while True:
    p = int(input('Digite o primeiro termo: '))
    r = int(input('Digite a razão: '))
    decimo = p + (10 - 1) * r
    for c in range(p, decimo + r, r):
        print(f'{c}', end=' ')
    cont = str(input('Esta P.A está concluida, deseja continuar? [S/N] ')).upper()
    if cont == 'N':
        break
print('FIM DO PROGRAMA')