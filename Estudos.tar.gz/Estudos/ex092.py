'''Exercício Python 092: Crie um programa que leia nome, ano de nascimento e carteira de trabalho e cadastre-o (com idade) em um dicionário. Se por acaso a CTPS
for diferente de ZERO, o dicionário receberá também o ano de contratação e o salário. Calcule e acrescente, além da idade, com quantos anos a pessoa vai se aposentar.'''

from datetime import date

cadastro = dict()
aposentadoria = 65
contribuicao = 30

cadastro['nome'] = str(input('Informe seu nome completo: '))
ano = int(input('Informe o ano do seu nascimento: '))
data = date.today().year
cadastro['idade'] = data - ano
cadastro['ctps'] = int(input('Quantos anos de trabalho registrado você possui?: '))
if cadastro['ctps'] != 0:
    anoContratado = int(input('Informe o seu ano de contratação: '))
    cadastro['salario'] = float(input('Informe seu último salário: '))

apos = contribuicao - cadastro['ctps']
inss = aposentadoria - cadastro['idade']

print(f'Seus dados completos são {cadastro}')
print(f'Para você se aposentar ainda terá que trabalhar mais {apos} anos, e completar 65 anos de idade que ainda faltam {inss}.')
